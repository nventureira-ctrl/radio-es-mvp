import { NextRequest, NextResponse } from "next/server";
import { ingestRadioDNS } from "@/lib/ingest-radiodns";

export async function POST(req: NextRequest) {
  const auth = req.headers.get('authorization') || '';
  const token = auth.replace('Bearer ', '');
  if (!process.env.CRON_SECRET || token !== process.env.CRON_SECRET) {
    return new NextResponse('Unauthorized', { status: 401 });
  }
  const body = await req.json().catch(() => ({} as any));
  if (!body?.src) return NextResponse.json({ error: 'Missing src' }, { status: 400 });

  const xml = await fetch(body.src).then(r => r.text());
  const res = await ingestRadioDNS(xml, body.networkSlug, body.networkName);
  return NextResponse.json({ ok: true, ...res });
}
