import { NextRequest, NextResponse } from "next/server";
import { ingestGenericJson } from "@/lib/ingest-generic-json";

export async function POST(req: NextRequest) {
  const auth = req.headers.get("authorization") || "";
  const token = auth.replace("Bearer ", "");
  if (!process.env.ADMIN_SECRET || token !== process.env.ADMIN_SECRET) {
    return new NextResponse("Unauthorized", { status: 401 });
  }
  const payload = await req.json();
  const res = await ingestGenericJson(payload);
  return NextResponse.json(res);
}
