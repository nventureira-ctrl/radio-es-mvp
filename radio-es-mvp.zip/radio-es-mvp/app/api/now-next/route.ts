import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { nowNextForStation } from "@/lib/schedule";

export async function GET() {
  const stations = await prisma.station.findMany({ select: { id: true, name: true } });
  const results = await Promise.all(stations.map(async (s) => {
    const nn = await nowNextForStation(s.id);
    return {
      stationId: s.id,
      stationName: s.name,
      now: nn.now ? { title: nn.now.title, start: nn.now.startISO, end: nn.now.endISO } : undefined,
      next: nn.next ? { title: nn.next.title, start: nn.next.startISO, end: nn.next.endISO } : undefined,
    };
  }));
  return NextResponse.json(results);
}
