import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

function parseCSV(text: string) {
  const lines = text.split(/\r?\n/).filter(Boolean);
  const headers = lines.shift()!.split(',');
  return lines.map(line => {
    const cells: string[] = [];
    let cur = '';
    let inQuotes = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (ch === '"') inQuotes = !inQuotes;
      else if (ch === ',' && !inQuotes) { cells.push(cur); cur = ''; }
      else { cur += ch; }
    }
    cells.push(cur);
    const obj: any = {};
    headers.forEach((h, idx) => obj[h.trim()] = (cells[idx] || '').trim());
    return obj;
  });
}

export async function POST(req: NextRequest) {
  const auth = req.headers.get('authorization') || '';
  const token = auth.replace('Bearer ', '');
  if (!process.env.ADMIN_SECRET || token !== process.env.ADMIN_SECRET) {
    return new NextResponse('Unauthorized', { status: 401 });
  }
  const text = await req.text();
  const rows = parseCSV(text);
  let created = 0;
  for (const r of rows) {
    if (!r.stationSlug) continue;
    const st = await prisma.station.findUnique({ where: { slug: r.stationSlug } });
    if (!st) continue;
    const pr = await prisma.programme.upsert({
      where: { slug: r.programmeSlug },
      update: { title: r.programmeTitle },
      create: { slug: r.programmeSlug, title: r.programmeTitle },
    });
    const dow = String(r.dow).split('|').map((n) => parseInt(n, 10));
    await prisma.scheduleRule.create({ data: { stationId: st.id, programmeId: pr.id, dow, startLocal: r.startLocal, endLocal: r.endLocal } });
    created++;
  }
  return NextResponse.json({ ok: true, created });
}
