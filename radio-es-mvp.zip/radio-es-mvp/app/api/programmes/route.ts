import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";

export async function GET() {
  const programmes = await prisma.programme.findMany({ orderBy: { title: "asc" } });
  return NextResponse.json(programmes);
}
