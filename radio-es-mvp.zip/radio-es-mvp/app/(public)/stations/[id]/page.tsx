import { prisma } from "@/lib/db";
import { notFound } from "next/navigation";

export default async function StationPage({ params }: { params: { id: string } }) {
  const station = await prisma.station.findFirst({
    where: { OR: [{ slug: params.id }, { id: params.id }] },
    include: { region: true, network: true, schedules: { include: { programme: true } } },
  });
  if (!station) return notFound();

  return (
    <div>
      <div>
        <h1 style={{fontSize:24, fontWeight:600}}>{station.name}</h1>
        <p style={{color:'#666'}}>{station.frequency ?? ''} · {station.region?.province ?? ''} · {station.network?.name ?? ''}</p>
      </div>
      <section style={{marginTop:16}}>
        <h2 style={{fontWeight:600, marginBottom:8}}>Parrilla recurrente (hoy)</h2>
        <ul style={{border:'1px solid #eee', borderRadius:12, background:'#fff', listStyle:'none', padding:0}}>
          {station.schedules.map((r) => (
            <li key={r.id} style={{padding:'10px 12px', display:'flex', justifyContent:'space-between', borderTop:'1px solid #f3f3f3'}}>
              <span style={{color:'#666'}}>{r.startLocal}–{r.endLocal}</span>
              <span style={{fontWeight:500}}>{r.programme.title}</span>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
