'use client';
import useSWR from 'swr';
import { useMemo, useState } from 'react';

const fetcher = (url: string) => fetch(url).then(r => r.json());

export default function HomePage() {
  const [province, setProvince] = useState('');
  const [q, setQ] = useState('');
  const query = useMemo(() => {
    const sp = new URLSearchParams();
    if (province) sp.set('province', province);
    if (q) sp.set('q', q);
    return sp.toString();
  }, [province, q]);

  const { data: stations } = useSWR(`/api/stations${query ? `?${query}` : ''}`, fetcher);
  const { data: nowNext } = useSWR('/api/now-next', fetcher, { refreshInterval: 60000 });
  const nnByStation = new Map(nowNext?.map((x: any) => [x.stationId, x]));

  const provinces = useMemo(() => {
    const set = new Set<string>();
    stations?.forEach((s: any) => s.region?.province && set.add(s.region.province));
    return Array.from(set).sort();
  }, [stations]);

  return (
    <div>
      <h1 style={{fontSize:24, fontWeight:600, marginBottom:12}}>Ahora en emisión</h1>

      <div style={{display:'flex', gap:8, alignItems:'center', marginBottom:16}}>
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar emisora..." style={{padding:'8px 10px', border:'1px solid #ddd', borderRadius:8}} />
        <select value={province} onChange={(e) => setProvince(e.target.value)} style={{padding:'8px 10px', border:'1px solid #ddd', borderRadius:8}}>
          <option value="">Todas las provincias</option>
          {provinces.map((p) => (<option key={p} value={p}>{p}</option>))}
        </select>
      </div>

      <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(260px, 1fr))', gap:12}}>
        {stations?.map((s: any) => {
          const nn = nnByStation.get(s.id);
          return (
            <a key={s.id} href={`/stations/${s.slug}`} style={{border:'1px solid #e5e5e5', borderRadius:12, background:'#fff', padding:12}}>
              <div style={{fontSize:12, color:'#666'}}>{s.region?.province ?? '—'}</div>
              <div style={{fontWeight:600, marginTop:4}}>{s.name}</div>
              <div style={{fontSize:12, color:'#666'}}>{s.frequency ?? ''}</div>
              <div style={{marginTop:8, fontSize:14}}>
                {nn?.now ? (
                  <>
                    <div style={{color:'#666'}}>En emisión</div>
                    <div style={{fontWeight:600}}>{nn.now.title}</div>
                  </>
                ) : (
                  <div style={{color:'#666'}}>Sin datos de ahora</div>
                )}
                {nn?.next && (
                  <div style={{marginTop:6, color:'#666'}}>A continuación: <span style={{color:'#111'}}>{nn.next.title}</span></div>
                )}
              </div>
            </a>
          );
        })}
      </div>
    </div>
  );
}
