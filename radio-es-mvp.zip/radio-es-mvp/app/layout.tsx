import "./globals.css";
import type { ReactNode } from "react";

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="es">
      <body>
        <header style={{position:'sticky',top:0,background:'#fff',borderBottom:'1px solid #eee',padding:'12px 16px'}}>
          <strong>Radio España</strong> <span style={{color:'#888'}}>MVP</span>
        </header>
        <main style={{maxWidth:900, margin:'0 auto', padding:'16px'}}>{children}</main>
      </body>
    </html>
  );
}
