import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import tz from "dayjs/plugin/timezone";

dayjs.extend(utc); dayjs.extend(tz);
export const MADRID_TZ = "Europe/Madrid";
export const nowMadrid = () => dayjs().tz(MADRID_TZ);

export function toTodayDateTime(localHHmm: string) {
  const [h, m] = localHHmm.split(":").map(Number);
  return nowMadrid().hour(h).minute(m).second(0).millisecond(0);
}
