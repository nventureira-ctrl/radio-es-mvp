import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import tz from "dayjs/plugin/timezone";
import { prisma } from "@/lib/db";

dayjs.extend(utc); dayjs.extend(tz);
const MADRID_TZ = "Europe/Madrid";

export type EventItem = {
  startISO: string;
  endISO: string;
  title: string;
  source: "rule" | "exception";
};

function localDateTime(dateLocal: dayjs.Dayjs, hhmm: string) {
  const [h, m] = hhmm.split(":").map(Number);
  return dateLocal.hour(h).minute(m).second(0).millisecond(0);
}
function toUTC(d: dayjs.Dayjs) { return d.tz(MADRID_TZ).utc(); }

export async function expandStationDay(stationId: string, ymd: string): Promise<EventItem[]> {
  const day = dayjs.tz(ymd, MADRID_TZ);
  const prev = day.subtract(1, "day");

  const dow = day.day();
  const dowPrev = prev.day();

  const rulesToday = await prisma.scheduleRule.findMany({
    where: { stationId, dow: { has: dow } },
    include: { programme: true },
  });
  const rulesPrev = await prisma.scheduleRule.findMany({
    where: { stationId, dow: { has: dowPrev } },
    include: { programme: true },
  });

  const exList = await prisma.scheduleException.findMany({
    where: { stationId, date: { gte: day.startOf("day").toDate(), lt: day.endOf("day").toDate() } },
  });

  const events: EventItem[] = [];

  for (const r of rulesToday) {
    const startLocal = localDateTime(day, r.startLocal);
    let endLocal = localDateTime(day, r.endLocal);
    if (endLocal.isSameOrBefore(startLocal)) endLocal = endLocal.add(1, "day");
    events.push({ startISO: toUTC(startLocal).toISOString(), endISO: toUTC(endLocal).toISOString(), title: r.programme.title, source: "rule" });
  }

  for (const r of rulesPrev) {
    const startLocal = localDateTime(prev, r.startLocal);
    let endLocal = localDateTime(prev, r.endLocal);
    if (endLocal.isSameOrBefore(startLocal)) endLocal = endLocal.add(1, "day");
    if (endLocal.isAfter(day.startOf("day")) && startLocal.isBefore(day.endOf("day"))) {
      const s = startLocal.isBefore(day.startOf("day")) ? day.startOf("day") : startLocal;
      const e = endLocal.isAfter(day.endOf("day")) ? day.endOf("day") : endLocal;
      events.push({ startISO: toUTC(s).toISOString(), endISO: toUTC(e).toISOString(), title: r.programme.title, source: "rule" });
    }
  }

  for (const ex of exList) {
    const sLocal = localDateTime(day, ex.startLocal);
    let eLocal = localDateTime(day, ex.endLocal);
    if (eLocal.isSameOrBefore(sLocal)) eLocal = eLocal.add(1, "day");
    const sISO = toUTC(sLocal).toISOString();
    const eISO = toUTC(eLocal).toISOString();

    const kept: EventItem[] = [];
    const overlap = (aStart: string, aEnd: string) => !(dayjs(aEnd).isSameOrBefore(sISO) || dayjs(aStart).isSameOrAfter(eISO));
    for (const ev of events) if (!overlap(ev.startISO, ev.endISO)) kept.push(ev);
    events.length = 0; events.push(...kept);

    events.push({ startISO: sISO, endISO: eISO, title: ex.title, source: "exception" });
  }

  events.sort((a,b) => a.startISO.localeCompare(b.startISO));
  const compact: EventItem[] = [];
  for (const ev of events) {
    const last = compact[compact.length - 1];
    if (last && last.title === ev.title && last.endISO === ev.startISO && last.source === ev.source) last.endISO = ev.endISO;
    else compact.push({ ...ev });
  }

  return compact;
}

export async function nowNextForStation(stationId: string) {
  const now = dayjs().tz(MADRID_TZ).utc();
  const ymd = dayjs().tz(MADRID_TZ).format("YYYY-MM-DD");
  const events = await expandStationDay(stationId, ymd);
  const current = events.find(e => dayjs(e.startISO).isSameOrBefore(now) && dayjs(e.endISO).isAfter(now));
  const upcoming = events.find(e => dayjs(e.startISO).isAfter(now));
  return { now: current, next: upcoming };
}
