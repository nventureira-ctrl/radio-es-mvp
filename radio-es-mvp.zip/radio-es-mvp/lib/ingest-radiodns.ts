import { PrismaClient } from "@prisma/client";
import { XMLParser } from "fast-xml-parser";

const prisma = new PrismaClient();

export async function ingestRadioDNS(xmlText: string, networkSlug = "radiodns-demo", networkName = "RadioDNS Demo") {
  const parser = new XMLParser({ ignoreAttributes: false, attributeNamePrefix: "@_" });
  const doc = parser.parse(xmlText);
  const network = await prisma.network.upsert({ where: { slug: networkSlug }, update: { name: networkName }, create: { slug: networkSlug, name: networkName } });
  const services = doc?.serviceInformation?.services?.service ?? [];
  const arr = Array.isArray(services) ? services : [services];
  for (const s of arr) {
    const name: string = s?.shortName || s?.mediumName || s?.longName || "Servicio";
    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
    await prisma.station.upsert({ where: { slug }, update: { name, networkId: network.id }, create: { slug, name, networkId: network.id } });
  }
  return { count: arr.length };
}
