import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();

export type IngestJson = {
  network: { slug: string; name: string };
  stations: Array<{ slug: string; name: string; regionCode?: string; frequency?: string; }>;
  programmes: Array<{ slug: string; title: string; synopsis?: string; hosts?: string[]; genre?: string }>;
  schedules: Array<{ stationSlug: string; programmeSlug: string; dow: number[]; startLocal: string; endLocal: string }>;
};

export async function ingestGenericJson(payload: IngestJson) {
  const net = await prisma.network.upsert({ where: { slug: payload.network.slug }, update: { name: payload.network.name }, create: { slug: payload.network.slug, name: payload.network.name } });
  const regionCache = new Map<string, string>();

  for (const s of payload.stations) {
    let regionId: string | undefined = undefined;
    if (s.regionCode) {
      const key = s.regionCode;
      if (regionCache.has(key)) regionId = regionCache.get(key)!;
      else {
        const reg = await prisma.region.upsert({ where: { code: key }, update: {}, create: { code: key, ccaa: key.split('-')[1] || '', province: key.split('-')[2] || '' } });
        regionId = reg.id; regionCache.set(key, reg.id);
      }
    }
    await prisma.station.upsert({
      where: { slug: s.slug },
      update: { name: s.name, networkId: net.id, frequency: s.frequency, regionId },
      create: { slug: s.slug, name: s.name, networkId: net.id, frequency: s.frequency, regionId },
    });
  }

  for (const p of payload.programmes) {
    await prisma.programme.upsert({
      where: { slug: p.slug },
      update: { title: p.title, synopsis: p.synopsis, hosts: p.hosts || [], genre: p.genre, networkId: net.id },
      create: { slug: p.slug, title: p.title, synopsis: p.synopsis, hosts: p.hosts || [], genre: p.genre, networkId: net.id },
    });
  }

  for (const r of payload.schedules) {
    const st = await prisma.station.findUnique({ where: { slug: r.stationSlug } });
    const pr = await prisma.programme.findUnique({ where: { slug: r.programmeSlug } });
    if (!st || !pr) continue;
    await prisma.scheduleRule.create({ data: { stationId: st.id, programmeId: pr.id, dow: r.dow, startLocal: r.startLocal, endLocal: r.endLocal } });
  }
  return { ok: true };
}
